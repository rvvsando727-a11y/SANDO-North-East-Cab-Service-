SANDO North East Cab Service — Website Package

HOW TO OPEN:
1. Extract/unzip this folder.
2. Open index.html in Chrome, Safari, Edge, or Firefox.
3. The website's destination/road-trip images are stored locally in the images folder.

CONTACT:
Call / WhatsApp: 76408 60646
Location: Near Department of Atomic Energy, Nongmensong, Shillong, Meghalaya

IMPORTANT:
The included scenic visuals are locally packaged promotional/generated visuals so the demo does not depend on external image hosts.
Before commercial launch, replace any representative vehicle images with your actual fleet photos or properly licensed manufacturer/dealer images.
